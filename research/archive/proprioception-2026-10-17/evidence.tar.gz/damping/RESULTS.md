# Sensing comparison

Power is modeled propeller shaft power from retained RPM, not battery power.

| Mode | Variant | Complete | Pitch RMS ° | Alt RMS m | Xtrack RMS m | Late pitch RMS ° | Shaft W | Common brake % |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| AUTO | sensor | 8/8 | 3.831 | 3.804 | 4.552 | 0.033 | 71.005 | 3.501 |
| CRUISE | sensor | 8/8 | 3.870 | 1.676 | 0.406 | 0.030 | 68.056 | 2.362 |

## Sensor fidelity

| Variant | Canopy angle error ° | Canopy rate error °/s | Airspeed error m/s | Airspeed use |
|---|---:|---:|---:|---:|
| sensor | 0.721 | 3.442 | 0.158 | 1.000 |

## Failures

