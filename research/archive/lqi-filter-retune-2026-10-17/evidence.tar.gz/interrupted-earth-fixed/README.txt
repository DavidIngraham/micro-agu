Interrupted before gain selection when the earth-fixed gust direction confound was identified. All 25 snapshotted files restored. These runs are excluded from retuning and validation.
