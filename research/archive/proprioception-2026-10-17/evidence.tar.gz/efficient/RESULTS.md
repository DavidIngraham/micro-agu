# Sensing comparison

Power is modeled propeller shaft power from retained RPM, not battery power.

| Mode | Variant | Complete | Pitch RMS ° | Alt RMS m | Xtrack RMS m | Late pitch RMS ° | Shaft W | Common brake % |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| AUTO | sensor | 2/2 | 3.766 | 3.622 | 10.788 | 0.025 | 69.402 | 3.477 |
| CRUISE | sensor | 2/2 | 3.872 | 2.226 | 0.223 | 0.038 | 67.403 | 1.748 |

## Sensor fidelity

| Variant | Canopy angle error ° | Canopy rate error °/s | Airspeed error m/s | Airspeed use |
|---|---:|---:|---:|---:|
| sensor | 1.133 | 3.130 | 0.156 | 1.000 |

## Failures

